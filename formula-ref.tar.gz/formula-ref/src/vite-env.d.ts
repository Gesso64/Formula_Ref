
declare module '*.css' {}
